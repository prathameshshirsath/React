import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const AppointmentDetails = () => {
    const { pid } = useParams();

    const [patientData, patientDataChange] = useState({});

    useEffect(() => {
        fetch("http://localhost:3000/appointment/" + pid).then((res) => {
            return res.json();
        }).then((resp) => {
            patientDataChange(resp);
        }).catch((err) => {
            console.log(err.message);
        })
    }, []);

    return (
        <div>
            <div className="container main">
                <div className="card row outside ">
                    <div className="card-title">
                        <h2 className="head">Appointment Details</h2>
                    </div>
                    <div className="card-body"></div>

                    {patientData &&
                        <div className="detail">
                            <h5>Patient name : {patientData.name}</h5>
                            <h5>Patient id :{patientData.id}</h5>
                            <h5>Patient Age : {patientData.age}</h5>
                            <h5>Patient phone : {patientData.phone}</h5>
                            <h5>Appointment date  : {patientData.date}</h5>
                            <h5>Appointment time  : {patientData.time}</h5>
                            <h5>Treatment notes :{patientData.notes}</h5>
                            <Link className="btn btn-danger listing" to="/Patient">Back to Listing</Link>
                        </div>
                    }
                </div>
            </div>
        </div >
    );
}

export default AppointmentDetails;