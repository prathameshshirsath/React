import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Formik, Form, Field } from 'formik';
import { object, string, number, date, time } from 'yup';
import '../App.css'

const initialValues = {
  name: '',
  age: '',
  phone: '',
  date: '',
  time: ''
}

const AddAppointment = () => {

  const [id, idchange] = useState("");
  const [active, activechange] = useState(true);


  const navigate = useNavigate();

  //const variable
  const phoneRegExp = /^[0-9]{10}$/;

  const validationSchema = object({
    name: string().required().min(3).max(30),
    phone: string().matches(phoneRegExp, 'phone number is not valid').required('Phone number is required'),
    age: number().required('age required').min(0, 'Age should be greater than zero').max(100),
    date: date().min(new Date(), 'Date must be higher than today').required('Date is required'),
    time: string().required('Time is required')


  });

  const handleSubmit = (values) => {

    fetch("http://localhost:3000/appointment", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(values)
    }).then((res) => {
      alert('Saved successfully.')
      navigate('/Patient');
    }).catch((err) => {
      console.log(err.message)
    })

  }

  return (
    <div>
      <div className="row">
        <div className="offset-lg-3 col-lg-6">
          <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
            {({ values, errors }) => (
              <Form className="container">

                <div className="card outer" style={{ "textAlign": "left" }}>
                  <div className="card-title">
                    <h2 className="heading">Appointment Form</h2>
                  </div>
                  <div className="card-body">

                    <div className="row">

                      {/* <div className="col-lg-12">
                        <div className="form-group">
                          <label>ID</label>
                          <input value={id} disabled="disabled" className="form-control"></input>
                        </div>
                      </div> */}

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="name">Name</label>
                          <Field type="text" id="name" name='name' className="form-control" />
                          <p className="err">{errors.name}</p>
                          {/* {name.length==0 && validation && <span className="text-danger">Enter the name</span>} */}
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="age">Age</label>
                          <Field type="number" id="age" name='age' className="form-control" />
                          <p className="err">{errors.age}</p>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Phone</label>
                          <Field type="string" id="phone" name='phone' className="form-control" />
                          <p className="err">{errors.phone}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Date</label>
                          <Field type="date" id="date" name='date' className="form-control" />
                          <p className="err">{errors.date}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Time</label>
                          <Field type="time" id="time" name='time' className="form-control" />
                          <p className="err">{errors.time}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Notes</label>
                          <Field type="text" id="text" disabled="disabled" name='notes' className="form-control" />
                          <p className="err">{errors.notes}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <button className="btn btn-success" type="submit">Save</button>
                          <Link to="/Patient" className="btn btn-danger">Back</Link>
                          <Link to="/" className="btn btn-primary button">Logout</Link>
                        </div>
                        
                      </div>

                    </div>

                  </div>

                </div>

              </Form>
            )}
          </Formik>

        </div>
      </div>
    </div>
  );
}

export default AddAppointment;


