import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const AppointmentDetails = () => {
    const { pid } = useParams();

    const [patientData, patientDataChange] = useState({});

    useEffect(() => {
        fetch("http://localhost:3000/appointment/" + pid).then((res) => {
            return res.json();
        }).then((resp) => {
            patientDataChange(resp);
        }).catch((err) => {
            console.log(err.message);
        })
    }, []);
    
    return (
        <div>
            <div className="container main">
                <div className="card row">
                    <div className="card-title">
                        <h2>Employee Create</h2>
                    </div>
                    <div className="card-body"></div>

                    {patientData &&
                        <div>
                            <h2>The Employee name is : <b>{patientData.name}</b>  ({patientData.id})</h2>
                            <h3>Contact Details</h3>
                            <h5>Age is : {patientData.age}</h5>
                            <h5>Phone is : {patientData.phone}</h5>
                            <h5>date is : {patientData.date}</h5>
                            <h5>time is : {patientData.time}</h5>
                            <h5>notes are :{patientData.notes}</h5>
                            <Link className="btn btn-danger" to="/">Back to Listing</Link>
                        </div>
                       
                    }
                </div>
            </div>
        </div >
    );
}

export default AppointmentDetails;