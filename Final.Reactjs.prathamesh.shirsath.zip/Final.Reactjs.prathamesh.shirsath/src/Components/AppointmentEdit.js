import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Formik, Form, Field } from 'formik';
import { object, string, number, date } from 'yup';

const initialValues = {
  name: '',
  age: '',
  phone: '',
  date: '',
  time: '',
  notes: ''


}


const AppointmentEdit = () => {
  const { pid } = useParams();

  const phoneRegExp = /^[0-9]{10}$/;

  const validationSchema = object({
    name: string().required().min(3).max(30),
    phone: string().matches(phoneRegExp, 'phone number is not valid').required('Phone number is required'),
    age: number().required('age required').min(0, 'Age should be greater than zero').max(100),
    date: date().min(new Date(), 'Date must be higher than today').required('Date is required'),
    time: string().required('Time is required')
  });

  useEffect(() => {
    fetch("http://localhost:3000/appointment/" + pid).then((res) => {
      return res.json();
    }).then((resp) => {
      idchange(resp.id);
      initialValues.name = resp.name;
      initialValues.age = resp.age;
      initialValues.phone = resp.phone;
      initialValues.date = resp.date;
      initialValues.time = resp.time;
      initialValues.notes = resp.notes;
    }).catch((err) => {
      console.log(err.message);
    })
  }, []);

  const [id, idchange] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (values) => {

    fetch("http://localhost:3000/appointment/" + pid, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(values)
    }).then((res) => {
      alert('Saved successfully.')
      navigate('/Doctor');
    }).catch((err) => {
      console.log(err.message)
    })

  }
  return (
    <div>

      <div className="row">
        <div className="offset-lg-3 col-lg-6">
          <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
            {({ values, errors }) => (
              <Form className="container" >

                <div className="card" style={{ "textAlign": "left" }}>
                  <div className="card-title">
                    <h2>Employee Edit</h2>
                  </div>
                  <div className="card-body">

                    <div className="row">

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>ID</label>
                          <input value={id} disabled="disabled" className="form-control"></input>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="name">Name</label>
                          <Field type="text" id="name" name='name' disabled="disabled" className="form-control" />
                          <p className="err">{errors.name}</p>
                          {/* {name.length==0 && validation && <span className="text-danger">Enter the name</span>} */}
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label htmlFor="age">Age</label>
                          <Field type="number" id="age" name='age' disabled="disabled" className="form-control" />
                          <p className="err">{errors.age}</p>
                        </div>
                      </div>

                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Phone</label>
                          <Field type="string" id="phone" name='phone' disabled="disabled" className="form-control" />
                          <p className="err">{errors.phone}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Date</label>
                          <Field type="date" id="date" name='date' className="form-control" />
                          <p className="err">{errors.date}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Time</label>
                          <Field type="time" id="time" name='time' className="form-control" />
                          <p className="err">{errors.time}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <label>Notes</label>
                          <Field type="text" id="text"  name='notes' className="form-control" />
                          <p className="err">{errors.notes}</p>
                        </div>
                      </div>
                      <div className="col-lg-12">
                        <div className="form-group">
                          <button className="btn btn-success" type="submit">Save</button>
                          <Link to="/Patient" className="btn btn-danger">Back</Link>
                        </div>
                      </div>

                    </div>

                  </div>

                </div>

              </Form>
            )}
          </Formik>

        </div>
      </div>
    </div>
  );
}

export default AppointmentEdit;