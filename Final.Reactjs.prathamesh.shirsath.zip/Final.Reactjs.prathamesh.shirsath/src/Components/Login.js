// SignInForm.js
import React from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import {useNavigate } from 'react-router-dom';

const initialValues = {
  email: '',
  password: '',
};

const validationSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email address').required('Email is required'),
  password: Yup.string().required('Password is required'),
});


function Login() {
    const navigate = useNavigate()
    const onSubmit = (values, { setSubmitting }) => {
        // You can handle form submission here, e.g., make an API request
        console.log('Form submitted:', values);
        setSubmitting(false);
      
        if(values.email === "Patient@gmail.com" && values.password ==="Patient@123")
        {
          navigate('/Patient')
        }

        else if(values.email === "Doctor@gmail.com" && values.password ==="Doctor@123")
        {
          navigate('/Doctor')
        }
      };
      
  return (
    <div className="container">
      <h2>Sign In</h2>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={onSubmit}
      >
        {({ isSubmitting }) => (
          <Form>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <Field
                type="email"
                name="email"
                className="form-control"
                id="email"
              />
              <ErrorMessage name="email" component="div" className="text-danger" />
            </div>

            <div className="form-group">
              <label htmlFor="password">Password</label>
              <Field
                type="password"
                name="password"
                className="form-control"
                id="password"
              />
              <ErrorMessage
                name="password"
                component="div"
                className="text-danger"
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Signing in...' : 'Sign In'}
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default Login;
