import logo from './logo.svg';
import './App.css';
import Login from './Components/Login';
import Patient from './Components/Patient';
import { BrowserRouter,Route,Routes } from 'react-router-dom';
import Doctor from './Components/Doctor';
// import Home from './Components/Home';
import AddAppointment from './Components/AddAppointment';
import AppointmentDetails from './Components/AppointmentDetails';
import AppointmentEdit from './Components/AppointmentEdit';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        {/* <Route path='/' element={<Home/>}></Route> */}
        <Route path='/' element={<Login/>}></Route>
        <Route path='/Patient' element={<Patient />}></Route>
        <Route path='/Doctor' element={<Doctor/>}></Route>
        <Route path='/AppointmentAdd' element={<AddAppointment/>}></Route>
        <Route path='/AppointmentDetails/:pid' element={<AppointmentDetails/>}></Route>
        <Route path='/AppointmentEdit/:pid' element={<AppointmentEdit/>}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
