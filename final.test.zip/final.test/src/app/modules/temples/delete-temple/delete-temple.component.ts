
import { Component,EventEmitter,Output,Input } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import {TempleService} from '../temples-list/temple-service.service'

@Component({
  selector: 'app-delete-temple',
  templateUrl: './delete-temple.component.html',
  styleUrls: ['./delete-temple.component.scss']
})

export class DeleteTempleComponent {
  @Input() product: any;
  @Output() close = new EventEmitter();

  constructor(private productService : TempleService,
  private toastrService : ToastrService){} 

  //close the form
  public onClose(): void{
    this.close.emit(); 
  }

  //delete the record
  public onDelete(): void{
    this.deleteProduct(this.product)
  }

  private deleteProduct(product: any): void{
    this.productService.deleteProduct(product).subscribe((response: any) => {
      this.toastrService.success("devotees record deleted successfully","Success");
      this.onClose();
    },(error: any) => {
      this.toastrService.error("Error deleted product","Error")
    });
  }
}
