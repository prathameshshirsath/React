import { Component, EventEmitter, Input, Output } from '@angular/core'
import { FormControl, FormGroup, Validators } from '@angular/forms'
import { ToastrService } from 'ngx-toastr'
import { TempleService } from '../temples-list/temple-service.service'
@Component({
  selector: 'app-add-edit-temples',
  templateUrl: './add-edit-temples.component.html',
  styleUrls: ['./add-edit-temples.component.scss']
})
export class AddEditTemplesComponent {
  @Input() product: any
  @Output() close = new EventEmitter()

  // validations
  public productForm = new FormGroup({
    firstname: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.pattern(/^[A-Za-z\s]+$/)
    ]),
    lastname: new FormControl('', [
      Validators.required,
      Validators.minLength(2),
      Validators.pattern(/^[A-Za-z\s]+$/)
    ]),
    age: new FormControl('', [Validators.required]),
    queue: new FormControl('', [Validators.required]),
    gender: new FormControl('', [Validators.required]),
    date: new FormControl('', [Validators.required])
  })


  constructor (
    private TempleService: TempleService,
    private toastrService: ToastrService
  ) {}

  ngOnInit () {
    if (this.product) {
      this.productForm.patchValue(this.product)
    }
  }

  //create variable for store current date
  public currentDate: any = new Date()

  public onClose (): void {
    this.close.emit()
  }

  //do save functionality
  public save (): void {
    let payload = this.assignValueToModel()
    if (!this.product) {
      this.addProduct(payload)
    } else {
      this.updateProduct(payload)
    }
  }

  //add record
  private addProduct (payload: any): void {
    this.TempleService.addProduct(payload).subscribe(
      (response: any) => {
        this.toastrService.success(
          'devotees record added successfully',
          'Success'
        )
        this.onClose()
      },
      (error: any) => {
        this.toastrService.error('Error adding product', 'Error')
      }
    )
  }

  //update record
  private updateProduct (payload: any): void {
    this.TempleService.updateProduct(payload).subscribe(
      (response: any) => {
        this.toastrService.success(
          'Devotees list updated succefully',
          'Success'
        )
        this.onClose()
      },
      (error: any) => {
        this.toastrService.error('Error updated product', 'Error')
      }
    )
  }

  private assignValueToModel (): any {
    let product = {
      id: this.product ? this.product.id : 0,
      firstname: this.productForm.get('firstname')?.value,
      lastname: this.productForm.get('lastname')?.value,
      age: this.productForm.get('age')?.value,
      queue: this.productForm.get('queue')?.value,
      gender: this.productForm.get('gender')?.value,
      date: this.productForm.get('date')?.value
    }
    return product
  }

  //check wheather the function is valid
  public checkIfControlValid (controlName: any): boolean {
    return this.productForm.get(controlName)?.invalid &&
      this.productForm.get(controlName)?.errors &&
      (this.productForm.get(controlName)?.dirty ||
        this.productForm.get(controlName)?.touched)
      ? true
      : false
  }
  public checkControlHasError (controlName: any, error: any): boolean {
    return this.productForm.get(controlName)?.hasError(error) ? true : false
  }
}
