import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditTemplesComponent } from './add-edit-temples.component';

describe('AddEditTemplesComponent', () => {
  let component: AddEditTemplesComponent;
  let fixture: ComponentFixture<AddEditTemplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddEditTemplesComponent]
    });
    fixture = TestBed.createComponent(AddEditTemplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
