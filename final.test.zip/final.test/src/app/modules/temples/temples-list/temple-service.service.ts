import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})

//create TempleService
export class TempleService {
  public baseUrl = 'http://localhost:3000/temples';

  constructor(private http: HttpClient) {}

  public getProducts(): any {
    return this.http.get('http://localhost:3000/temples')
  }

  public addProduct(product:any):any{
    return this.http.post('http://localhost:3000/temples',product);
  }

  public updateProduct(product:any):any{
    return this.http.put(`http://localhost:3000/temples/${product.id}`,product);
  }

  public deleteProduct(product:any):any{
    return this.http.delete(`http://localhost:3000/temples/${product.id}`);
  }

}
