import { Component } from '@angular/core';
import {TempleService} from '../temples-list/temple-service.service'
import { ToastrService } from 'ngx-toastr';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AddEditTemplesComponent } from '../add-edit-temples/add-edit-temples.component';
import { DeleteTempleComponent } from '../delete-temple/delete-temple.component';

@Component({
  selector: 'app-temples-list',
  templateUrl: './temples-list.component.html',
  styleUrls: ['./temples-list.component.scss']
})

export class TemplesListComponent {
  public totalCount: number = 0;
  public products: any[] = [];
  public addEditProductModal !: BsModalRef;
  public deleteProductModal !: BsModalRef;

  constructor(private productService: TempleService,
    private toastrService: ToastrService,
    private modalService: BsModalService) {}

  ngOnInit(){
    this.loadProducts();
  }

  //To load the records
  private loadProducts(): void{
    this.productService.getProducts().subscribe((response: any) => {
      this.products = response;
      this.totalCount = this.products.length;
    },(error: any) => {
      this.toastrService.error("Error loading products list","Error")
    })
  } 

  //for add-edit list
  openAddEditProductModal(product: any = null): void {
    this.addEditProductModal = this.modalService.show(AddEditTemplesComponent,{
      initialState: { product: product}, class:"modal-lg",
      ignoreBackdropClick: true
    });

    this.addEditProductModal.content.close.subscribe(() => {
      this.addEditProductModal.hide();
      this.loadProducts();
    })
  }

  //for delete record in modal
  openDeleteProductModal(product: any): void{
    this.deleteProductModal = this.modalService.show(DeleteTempleComponent,{
      initialState: { product: product}, 
      class:"modal-sm",
      ignoreBackdropClick: true
    });

    this.deleteProductModal.content.close.subscribe(() => {
      this.deleteProductModal.hide();
      this.loadProducts();
    })
  }
}
