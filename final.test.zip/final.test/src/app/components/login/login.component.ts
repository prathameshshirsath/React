import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/helper/auth.service';
import { Router } from '@angular/router'
import { FormControl, FormGroup , FormBuilder,  Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm = new FormGroup({
    email: new FormControl("",[Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    password: new FormControl("",[Validators.required]),
  });
  constructor(private auth: AuthService, private router: Router) {}

  //check validations for login
  public checkIfControlValid(controlName: string):any{
    return this.loginForm.get(controlName)?.invalid &&
    this.loginForm.get(controlName)?.errors && 
      (this.loginForm.get(controlName)?.dirty || this.loginForm.get(controlName)?.touched);
  }

  public checkControlHasError(controlName: string , error:string):any{
    return this.loginForm.get(controlName)?.hasError(error);
  }

  ngOnInit(): void {
    if (this.auth.isLoggedIn()) {
      this.router.navigate(['admin']);
    }
  }
  
  //handle onclick submit functionlity
  onSubmit(): void {
    if (this.loginForm.valid) {
      this.auth.login(this.loginForm.value).subscribe(
        (result) => {
          console.log(result);
          this.router.navigate(['/admin']);
        },
        (err: Error) => {
          alert(err.message);
        }
      );
    }
  }
}
